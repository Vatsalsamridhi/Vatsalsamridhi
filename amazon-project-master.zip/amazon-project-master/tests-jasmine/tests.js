import { testFormatCurrency } from "./tests/utils/moneyTests.js";
import { testAddToCart } from "./tests/data/cartTests.js";

testFormatCurrency()
testAddToCart()