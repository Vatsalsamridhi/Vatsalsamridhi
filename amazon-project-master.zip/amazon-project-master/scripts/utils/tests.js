import {testFormatCurrency} from "./tests/moneyTests.js";

testFormatCurrency()